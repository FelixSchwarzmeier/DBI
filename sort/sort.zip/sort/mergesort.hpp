//
//  mergesort.hpp
//  sort
//
//  Created by Julia Kindelsberger on 16/04/16.
//  Copyright © 2016 Julia Kindelsberger. All rights reserved.
//

#ifndef mergesort_hpp
#define mergesort_hpp

#include <stdint.h>
#include <stdio.h>

void externalSort(int, uint64_t, int, uint64_t);

#endif /* mergesort_hpp */
