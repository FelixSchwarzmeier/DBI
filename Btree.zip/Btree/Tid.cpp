#include "Tid.hpp"

/*TID::TID(uint64_t pageId, unsigned slotId) : pageId(pageId), slotId(slotId) {
}

uint64_t TID::getPageId() {
    return pageId;
}
unsigned TID::getSlotId() {
    return pageId;
}
*/